def lambda_handler(event, context):
    print("Hello from Lambda!")
    print("Received event: ", event)
